const objectAssign = require('object-assign');

module.exports = function(view) {
	return function(dispatcher, ...actionFiles) {
		actionFiles.forEach((actionFile) => {
			  view.prototype["props"] = objectAssign({}, view.prototype["props"], actionFile(dispatcher));
		});
		return view;
	};
}