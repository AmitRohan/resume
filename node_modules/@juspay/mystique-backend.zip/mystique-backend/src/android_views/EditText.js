var dom = require('../doms').android;
var View = require('../base_views').AndroidBaseView;

class EditText extends View {
  constructor(props, children) {
    super(props, children);

    this.setIds([
      'id',
    ]);

    var _this = this;
  }

  render() {
    var params = this.props;
    console.log("params", params)
    params.__filename = params.__source.fileName + ' :ln ' + params.__source.lineNumber;

    return (
      <editText
			    fontStyle = {this.props.fontStyle?this.props.fontStyle:"OpenSans/Regular"}
				id={this.props.id?this.props.id:this.idSet.id}  
				params={params}/>
    )
  }
}

module.exports = EditText;
