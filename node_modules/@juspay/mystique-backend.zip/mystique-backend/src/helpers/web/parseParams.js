Array.prototype.rotate = (function() {
    // save references to array functions to make lookup faster
    var push = Array.prototype.push,
        splice = Array.prototype.splice;

    return function(count) {
        var len = this.length >>> 0, // convert to uint
            count = count >> 0; // convert to int

        // convert count to value in range [0, len)
        count = ((count % len) + len) % len;

        // use splice.call() instead of this.splice() to make function generic
        push.apply(this, splice.call(this, 0, count));
        return this;
    };
})();

function flattenObject(ob) {
  var toReturn = {};
  for (var i in ob) {
    if (!ob.hasOwnProperty(i)) continue;
    if ((typeof ob[i]) == 'object') {
      var flatObject = flattenObject(ob[i]);
      for (var x in flatObject) {
        if (!flatObject.hasOwnProperty(x)) continue;
        toReturn[x] = flatObject[x];
      }
    } else {
      toReturn[i] = ob[i];
    }
  }
  return toReturn;
};

function parseLayoutProps(type, config, key) {
  if (typeof config[key] == "undefined" || config[key] == null) {
    delete config[key];
    return;
  }

  if (!config.style)
  config.style = {};

  if (!config.attributes)
  config.attributes = {};

  if (!config.style.className)
  config.style.className = "";

  if (key == "width"){
    if (config.width == "match_parent")
    config.style.width = "100%";
    else if (!isNaN(config.width*1))
    config.style.width = config.width;
  }

  if (key == "height"){
    if (config.height == "match_parent")
    config.style.height = "100%";
    else if (!isNaN(config.height*1))
    config.style.height = config.height;
  }

  if (key == "textSize")
  config.style.fontSize = config.textSize;

  if (key == "padding")
  config.style.padding = config.padding.split(",").rotate(1).join(" ");

  if (key == "margin")
  config.style.margin = config.margin.split(",").rotate(1).join(" ");

  if (key == "imageUrl")
  config.attributes.src = config.imageUrl + ".png";

  if (key == "background")
  config.style.background = config.background;

  if (key == "color")
  config.style.color = config.color;

  if (key == "alignParentBottom")
  config.style.bottom = 0;

  if (key == "cornerRadius") {
    config.style.borderRadius = config.cornerRadius + "px";
  }

  if (key == "visibility") {
    config.style.display = config.visibility == "gone" ? "none" : "";
  }

  if (key == "alpha") {
    config.style.opacity = config.alpha;
  }

  if (key == "fontStyle") {
    config.style.fontWeight = config.fontStyle.indexOf("Regular") > -1 ? "normal" : "bold";
  }

  if (key == "weight") {
    // only support equal weights
    // config.parentStyle.display = "flex";
    // config.parentStyle.justifyContent = "space-around";

    // config.style.display = "flex";
    // config.style.justifyContent = "space-around";
    // config.style.height = "50";
  }

  if (key == "translationY") {
    config.style.transform = "translateY(" + config.translationY + "px)";
  }

  if (key == "translationX") {
    config.style.transform = "translateX(" + config.translationX + "px)";
  }

  if (key == "a_translationY") {
    config.style.transform = "translateY(" + config.a_translationY + "px)";
  }

  if (key == "a_translationX") {
    config.style.transform = "translateX(" + config.a_translationX + "px)";
  }

  if (key == "id") {
    config.attributes.id = config.id;
  }
}

function setDefaults(type, config) {
  if (type == "linearLayout") {
    config.orientation = config.orientation  || "horizontal";
  }
}

module.exports = function(type, config, getSetType) {

  config = flattenObject(config);

  // cleanProps(); margin, padding, etc remove whitespace
  setDefaults(type, config);

  var keys = Object.keys(config);

  for (var i=0; i<keys.length; i++) {
    parseLayoutProps(type, config, keys[i]);
  }

  return config;
}
