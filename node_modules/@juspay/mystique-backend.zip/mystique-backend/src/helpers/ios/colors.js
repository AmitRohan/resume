module.exports = [
	"#83FCE8",
	"#89F6E4",
	"#8FEFDF",
	"#96E9DB",
	"#9CE3D7",
	"#FEE9E6",
	"#FEF7E7",
	"#FFFAE5",
	"#F5FAEB",
	"#E5FFF5"
]

