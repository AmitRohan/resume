var View = require("./View");

class WebBaseView extends View {
	constructor(props, children) {
		super(props, children);
	}
}

module.exports = WebBaseView;