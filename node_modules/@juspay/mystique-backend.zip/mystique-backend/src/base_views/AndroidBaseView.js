const View = require("./View");
const objectAssign = require('object-assign');
const parseParams = require('../helpers/web/parseParams');

class AndroidBaseView extends View {
  constructor(props, children) {
    super(props, children);

    window.__SETFN = function(config) {
      Android.runInUI(
        this.set(config),
        null
      )
    }.bind(this)
  }

  findRecurse(obj, selector) {
    var children = obj.children;

    for (var i =0; i< children.length; i++) {
      if (children[i].displayName && children[i].displayName == selector) {
      this.foundChildren.push(children[i]);
    }

      if (children[i].children && children[i].children.length)
      this.findRecurse(children[i], selector);
    }

    return;
  }

  find(selector, obj) {
    this.foundChildren = [];

    if (!obj)
      this.findRecurse(this.layout, selector);
    else
      this.findRecurse(obj, selector);

    return this.foundChildren;
  }

  animateView() {
    console.log(window.__CURR_SCREEN);
    console.log(window.__PREV_SCREEN);


    if (!window.__CURR_SCREEN || !window.__PREV_SCREEN)
    return "";

    var cmd = [];
    var _this = this;
    var width = window.__WIDTH + '';
    var direction = window.__ANIMATE_DIR;
    var initialPos = (direction == 1) ? width : '-' + width;
    var finalPos = (direction == 1) ? '-' + width : width;
    var fromScreenId = window.__CACHED_SCREENS[window.__PREV_SCREEN].screen.layout.idSet.id;
    var toScreenId = window.__CACHED_SCREENS[window.__CURR_SCREEN].screen.layout.idSet.id;

    // out of frame right now
    cmd.push(this.set({
      translationX: initialPos,
      id: toScreenId,
      a_translationX: '0',
      a_duration:"400",
      bringToFront: 'true',
    }));

    // in frame right now
    cmd.push(_this.set({
      id: fromScreenId,
      a_duration:"400",
      a_translationX: finalPos,
      visibility:"gone",
    }));

    return cmd;
  }

  setIds(arr) {
    this.idSet = {};

    for (var i =0; i<arr.length; i++) {
      window.__ID++;
      this.idSet[arr[i]] = window.__ID + '';
    }
  }

  handleSpecialChars(value) {
    value =  value.indexOf(',')>-1?value.replace(/\,/g, '\\\\,'):value;
    value =  value.indexOf(':')>-1?value.replace(/\:/g, '\\\\:'):value;
    value =  value.indexOf('=')>-1?value.replace(/\=/g, '\\\\='):value;
    value =  value.indexOf(';')>-1?value.replace(/\;/g, '\\\\;'):value;

    return value;
  }

  setForAndroid = () => {
    var cmd = "set_view=ctx->findViewById:i_" + config.id + ";";
    var runInUI;

    if (config.toast) {
        cmd =  "set_TOAST=android.widget.Toast->makeText:ctx_ctx,cs_" + this.handleSpecialChars(config.text) +",i_"+ (config.duration=="short"?0:1) + ";get_TOAST->show";
    } else if (config && Object.keys(config).length) {
        delete config.id;

        config.root = "true";
        runInUI = parseParams("linearLayout", config, "get").runInUI;

        cmd += runInUI + ';';
    }

    if (cmd.indexOf("undefined") > -1)
    console.log(config);

    return cmd;
  }

  setForWeb = (config) => {
    if (Object.keys(config).length)
    return parseParams("linearLayout", config, "set");
  }

  set(config) {
    if (!window.__SIMULATOR)
    return this.setForAndroid(config);

    return this.setForWeb(config);
  }

  appendChild(id, jsx, index ,fn, replaceChild) {
    var proxyFnName;
    if(!replaceChild) {
      replaceChild = false;
    }

    if (fn) {
      proxyFnName = 'F' + window.__FN_INDEX;
      window.__PROXY_FN[proxyFnName] = fn;
      window.__FN_INDEX++;
    }

    jsx = window.__OS ? jsx : JSON.stringify(jsx);

    if (proxyFnName)
      Android.addViewToParent(id, jsx, index, proxyFnName, replaceChild);
    else
      Android.addViewToParent(id, jsx, index, null, replaceChild);
  }

  getView(jsx){
    if (window.__SIMULATOR)
    return jsx;

    return JSON.stringify(jsx);
  }

  delete(id) {
    return "set_VIEW=ctx->findViewById:i_"+id+";set_PARENT=get_VIEW->getParent;get_PARENT->removeView:get_VIEW;"
  }

  removeAllChildren(id) {
    return "set_VIEW=ctx->findViewById:i_"+id+";get_VIEW->removeAllViews;"
  }

  replaceChild(id, jsx, index ,fn) {
    this.appendChild(id, jsx, index ,fn, true);
  }
}

module.exports = AndroidBaseView;
