var View = require("./View");
const parseParams = require('../helpers/ios/parseParams');

class IOSBaseView extends View {
	constructor(props, children) {
		super(props, children);
	}

	animateView(index, direction, _animate) {
		var cmd = [];
		var _this = this;
		var width = __WIDTH + '';
		var a_x = (direction == 1)?'-'+width : width;
		var animate = (typeof _animate != "undefined")?_animate:true;

		if (animate) {
			// prevScreen
			cmd =  cmd.concat(this.set({
				id: window.__CACHED_SCREENS[index].value.layout.idSet.id,
				a_translation: "true",
				a_x: a_x,
				a_duration: "0.3",
			}));
			
			// currScreen
			cmd =  cmd.concat(this.set({
				id: _this.layout.idSet.id,
				a_translation: "true",
				a_x: "0",
				a_duration: "0.3",
			}));	
		} else {		
			// prevScreen
			cmd = cmd.concat(this.set({
				id: window.__CACHED_SCREENS[index].value.layout.idSet.id,
				x: a_x,
			}));
			
			// currScreen
			cmd = cmd.concat(this.set({
				id: this.layout.idSet.id,
				x: '0',
			}));		
		}

		return cmd;
	}

	findRecurse(obj, selector) {
		var children = obj.children;
	   	
	  for (var i =0; i< children.length; i++) {
	    if (children[i].displayName && children[i].displayName == selector) {
	      this.foundChildren.push(children[i]);	
	    }

	    if (children[i].children && children[i].children.length)
	    this.findRecurse(children[i], selector); 
	  }
	   	
	  return;
	}

	find(selector, obj) {
	  this.foundChildren = [];

	  if (!obj)
	  this.findRecurse(this.layout, selector);
		else 
		this.findRecurse(obj, selector);	
		
	  return this.foundChildren;
	}

	setIds(arr) {
		this.idSet = {};

		for (var i =0; i<arr.length; i++) {
 			window.__ID++;
			this.idSet[arr[i]] = window.__ID + '';
		}
	}

	appendChild(id, jsx, fn) {
		window.__CURR_PARENT_INDEX = id;

		var proxyFnName;
		var data = {parentTag: id, view: jsx.render()};

		if (fn) {
			proxyFnName = 'F' + window.__FN_INDEX;
			window.__PROXY_FN[proxyFnName] = fn;
			window.__FN_INDEX++;
		}
		
		window.webkit.messageHandlers.IOS.postMessage(JSON.stringify({
			methodName : "addViewToParent", 
			parameters : {
				parentId : data.parentTag, 
				view : data.view
			}
		}));		
	}

	replaceChild(id, jsx, index ,fn) {
		window.__CURR_PARENT_INDEX = id;

		var proxyFnName;
		var data = {parentTag: id, view: jsx.render()};

		if (fn) {
			proxyFnName = 'F' + window.__FN_INDEX;
			window.__PROXY_FN[proxyFnName] = fn;
			window.__FN_INDEX++;
		}
		
		window.webkit.messageHandlers.IOS.postMessage(JSON.stringify({
			methodName : "replaceChild", 
			parameters : {
				index:index,
				parentId : data.parentTag, 
				view : data.view
			}
		}));
	}

	popViewController() {
		this.props.showScreen("GO_BACK");
		window.__SCREEN_INDEX--;
		window.webkit.messageHandlers.IOS.postMessage(JSON.stringify({
			methodName : "popViewController", 
			parameters : {}
		}));
	}

	popToViewController(index) {
		this.props.showScreen("GO_BACK."+index);
		window.webkit.messageHandlers.IOS.postMessage(JSON.stringify({
			methodName : "popToViewController", 
			parameters : {
				index  : index-1
			}
		}));
	}

	removeAllChildren(id) {
		window.webkit.messageHandlers.IOS.postMessage(JSON.stringify({
			methodName : "removeChildren", 
			parameters : {
				parentId : id
			}
		}));
	}

	set(config) {
		return parseParams("dummy",config, "get").methods;
	}


}

module.exports = IOSBaseView;