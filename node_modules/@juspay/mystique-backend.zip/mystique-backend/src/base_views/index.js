module.exports = {
	AndroidBaseView : require("./AndroidBaseView"),
	IOSBaseView : require("./IOSBaseView"),
	WebBaseView : require("./WebBaseView"),
	View : require("./View")
}