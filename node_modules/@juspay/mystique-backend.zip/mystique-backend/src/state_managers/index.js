module.exports = {
	dispatcher : require("./dispatcher"),
	reducer : require("./reducer")
}