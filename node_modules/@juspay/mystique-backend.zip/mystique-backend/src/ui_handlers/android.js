module.exports = {
	handle : (ui, callback) => {
		// IMPURE FUNCTIONS HERE. HAVE TO MOVE IT SOMEWHERE ELSE
		// CHECK IF MONADS CAN BE USED

		if(ui.render) {
		  if (typeof Android !== "undefined"){
        if (window.__OS)
		    Android.Render(ui.render, null)
        else
		    Android.Render(JSON.stringify(ui.render), null)
		  } else {
		  	// console.log(JSON.stringify(ui.render));
		  }
		}
		
		if(ui.runInUI) {
			Android.runInUI(ui.runInUI, null);
		}
		if(ui.addViewToParent) {
			Android.addViewToParent(ui.addViewToParent.parentId, JSON.stringify(ui.addViewToParent.jsx), ui.addViewToParent.index, null);
		}
	}	
}
