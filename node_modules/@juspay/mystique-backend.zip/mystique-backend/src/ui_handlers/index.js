module.exports = {
	android : require("./android"),
	ios : require("./ios"),
	web : require("./web")
}