module.exports = { 
	handle : (ui, callback) => { 
		
		if(ui.render) { 
			window.webkit.messageHandlers.IOS.postMessage(
				JSON.stringify({ 
					methodName : "render",
					parameters : { 
						view : ui.render, 
						animate : ui.animate 
					}})); 
		} 

		if(ui.runInUI) {
			window.webkit.messageHandlers.IOS.postMessage(
				JSON.stringify({
					methodName : "runInUI", 
					parameters : ui.runInUI
				})); 
		} 

		if(ui.addViewToParent) {
			window.webkit.messageHandlers.IOS.postMessage(
				JSON.stringify({ 
					methodName : "addViewToParent", 
					parameters : { 
						parentId : ui.addViewToParent.parentId, 
						view : ui.addViewToParent.jsx 
					} 
			})); 
		}

		if(ui.popViewController) {
			window.webkit.messageHandlers.IOS.postMessage(
				JSON.stringify({ 
					methodName : "popViewController", 
					parameters : {} 
			})); 
		} 

		if(ui.popToViewController) {
			window.webkit.messageHandlers.IOS.postMessage(
				JSON.stringify({ 
					methodName : "popToViewController", 
					parameters : {
						// index : 
					} 
			})); 
		} 
	}
}