module.exports = {
	UIView : require("./UIView"),
	UIImageView : require("./UIImageView"),
  	UILabel : require("./UILabel"),
  	UISwitch : require("./UISwitch"),
  	UITextView : require("./UITextView"),
	UIScrollView : require("./UIScrollView"),
	StackView : require("./StackView"),
	KAScrollView : require("./KAScrollView"),
	CollectionView : require("./CollectionView"),
	CustomTextField : require("./CustomTextField"),
	TableView : require("./TableView"),
}