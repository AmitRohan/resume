var dom = require('../doms').ios;
var View = require('../base_views').IOSBaseView;

class UISwitch extends View {
	constructor(props, children) {
		super(props, children);

		this.setIds([
			'id'
		]);
	}

	addDimensionToOrphanNodes() {
	    if (window.__CURR_PARENT_INDEX) {

	      this.props.width = this.getChildWidth(this.props, window.__IOS_VIEWS[window.__CURR_PARENT_INDEX].width);
	      this.props.height = this.getChildHeight(this.props, window.__IOS_VIEWS[window.__CURR_PARENT_INDEX].height);
	    }

	    window.__CURR_PARENT_INDEX = null;
  	}
  	
	render() {
		var params = this.props;
		var _this = this;
		var debug = params.debug || this.debug;
		params.__filename = params.__source.fileName  + ' :ln ' + params.__source.lineNumber;
		
		if (debug) {
			params.debug = "true";
		}

		this.addDimensionToOrphanNodes();

		return (
			<uISwitch
				id={this.props.id?this.props.id:this.idSet.id}  
				params={params}>

				{this.children.map(function(child) {
					child.debug = debug?"true":false
				 	return  child.render()
				})}

			</uISwitch>
		)
	}
}

module.exports = UISwitch;
