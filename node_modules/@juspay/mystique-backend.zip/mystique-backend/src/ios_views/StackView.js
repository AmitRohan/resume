var dom = require('../doms').ios;
var UIView = require('./UIView');

class StackView extends UIView {
	constructor(props, children) {
		super(props, children);

		this.setIds([
			'id'
		]);

    this.offsetY = 0;
		this.offsetX = 0;
	}

  setOffsetX(props, spacingRight) {
    let offsetX;
    let width;

    if (props.width == "remaining") {
      width = this.props.width*1 - this.offsetX;
      props.width = width;
    } else {
      width = props.width*1;
    }

    this.offsetX += width + spacingRight;
  }

  setOffsetY(props, spacingBottom) {
    let offsetY;
    let height;

    if (props.height == "remaining") {
      height = this.props.height*1 - this.offsetY;
      props.height = height;
    } else {
      height = props.height*1;
    }

    this.offsetY += height + spacingBottom;
  }

  getChildXPos(props) {
    if (this.orientation != "1")
    return props.x;

    let x = this.offsetX;
    let spacingRight = props.spacingRight*1 || 0;

    this.setOffsetX(props, spacingRight);
    
    return x;
  }

	getChildYPos(props) {
    if (this.orientation != "0")
    return props.y;

		let y = this.offsetY;
    let spacingBottom = props.spacingBottom*1 || 0;

    this.setOffsetY(props, spacingBottom);
    
		return y;
	}

  getWidth() {
    let  width = 0;
    this.children.forEach((child)=> {
      let spacingRight = child.props.spacingRight*1 || 0;
      width += (child.props.width*1 + spacingRight);
    });

    return width;
  }

  getHeight() {
    let  height = 0;
    this.children.forEach((child)=> {
      let spacingBottom = child.props.spacingBottom*1 || 0;
      height += (child.props.height*1 + spacingBottom);
    });

    return height;
  }

  setOrientation(params) {
    this.orientation = this.props.orientation?"1": "0";
  }

  setDimensions(params) {
    if (this.orientation == "1") { // horizontal
      if (typeof params.width === "undefined")
      params.width = this.getWidth();  
    } else { // vertical
      if (typeof params.height === "undefined")
      params.height = this.getHeight();
    }
  }

  resolveChildren(debug) {
    var _this = this;
    var width = this.props.width;
    var height = this.props.height;

    return this.children.map(function(child) {
      child.props.width = _this.getChildWidth(child.props, width);
      child.props.height = _this.getChildHeight(child.props, height);
      child.props.x =  _this.getChildXPos(child.props)
      child.props.y =  _this.getChildYPos(child.props)
      child.debug = debug?"true":false          
      return  child.render()
    });
  }

	render() {
		var params = this.props;
    var debug = params.debug || this.debug;
    var children;

    if (debug) {
      params.debug = "true";
    }

    this.addDimensionToOrphanNodes();
    
    this.setOrientation(params);
    children = this.resolveChildren(debug);
    this.setDimensions(params);
    params.__filename = params.__source.fileName  + ' :ln ' + params.__source.lineNumber;

		return (
			<uIView
				id={this.props.id?this.props.id:this.idSet.id}
				params={params}>

				{children}
			</uIView>
		)
	}
}

module.exports = StackView;
