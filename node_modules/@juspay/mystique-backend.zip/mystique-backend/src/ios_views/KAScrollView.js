var dom = require('../doms').ios;
var UIScrollView = require('./UIScrollView');

class KAScrollView extends UIScrollView {
  constructor(props, children) {
    super(props, children);

    this.setIds([
      'id'
    ]);
    
    this.offsetX = 0;
    this.offsetY = 0;
  }

  setContentDimension(params) {
    if (this.orientation == "1") { // horizontal
      params.contentWidth = this.getWidth();
      params.contentHeight = params.height;
    } else { // vertical
      params.contentHeight = this.getHeight();  
      params.contentWidth = params.width;
    }
  }

  render() {
    var params = this.props;
    var debug = params.debug || this.debug;
    var children;

    if (debug) {
      params.debug = "true";
    }

    this.addDimensionToOrphanNodes();  

    this.setOrientation(params);
    children = this.resolveChildren(debug);
    this.setContentDimension(params);
    params.__filename = params.__source.fileName  + ' :ln ' + params.__source.lineNumber;
    
    return (
      <tPKeyboardAvoidingScrollView
        id={this.props.id?this.props.id:this.idSet.id}
        params={params}>

        {children}
      </tPKeyboardAvoidingScrollView>
    )
  }
}

module.exports = KAScrollView;
