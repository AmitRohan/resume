Array.prototype.flatten = function() {
  return this.reduce(function(prev, cur) {
    var more = [].concat(cur).some(Array.isArray);
    return prev.concat(more ? cur.flatten() : cur);
  },[]);
};

var parseParams = require('../helpers/ios').parseParams;
	
module.exports = function(type, props, ...children){
	var paramType;

  children =  children.flatten();

  if (!props)
  props = {};
	
  if(typeof type === "string") {
    props =  parseParams(type, props, "set");
    
    props.node_id = window.__NODE_ID + '';
  	window.__NODE_ID++;

  	if (!props.__filename)
  	props.__filename = "filename not added";

    type = type[0].toUpperCase() + type.substr(1, type.length)
    
    return {type: type,  props: props, children: children}

  } else {
    return new type(props, children);
  }
}
