function run() {
  return {
    android : require("./web"),
    ios : require("./ios"),
    web : require("./web")
  }
}

module.exports = run();
